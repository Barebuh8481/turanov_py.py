n = int(input("Введите размерность квадратной матрицы (n):"))

matrix = []
print("Введите элементы матрицы построчно:")
for i in range(n):
    row = list(map(int, input(f"Введите {n} элементов для строки {i + 1}: ").split()))
    if len(row) != n:
        print("Неверное количество элементов в строке!")
        exit()
    matrix.append(row)

print("Исходная матрица:")
for row in matrix:
    print(row)

transp_matrix = [[matrix[j][i] for j in range(n)] for i in range(n)]


print("Транспонированная матрица:")
for row in transp_matrix:
    print(row)