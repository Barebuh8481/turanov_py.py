
name = input("Ваши фамилия, имя? ")
age = input("Сколько Вам лет? ")
loc = input("Где вы живете? ")

print("Ваши фамилия, имя", name)
print("Ваш возраст", age)
print("Вы живете в", loc)